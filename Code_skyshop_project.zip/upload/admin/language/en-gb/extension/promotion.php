<?php
// Heading Title
$_['heading_title']	= 'Promotion';
